
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `
You are the DeepMail Assistant, an AI expert integrated into a unified email and cloud storage platform.
Your primary tasks are:
1. Helping users find and summarize their emails.
2. Assisting with file management and organization.
3. Drafting professional emails or replies.
4. Answering productivity-related questions.

Maintain a professional, helpful, and concise tone. You have access to user context like current views and actions. 
If asked to generate an image or video, use the appropriate models.
`;

export async function getGeminiChatResponse(prompt: string, history: {role: string, parts: {text: string}[]}[]) {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
      },
    });

    return response.text || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I encountered an error connecting to my neural core. Please try again in a moment.";
  }
}
